<?php
  session_start();
  extract($_SESSION);
  // print_r($_SESSION);
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.html");
  }
  ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="index.css">
<style type="text/css">
  #landing-wrapper {
  display: table;
  width: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('im2.jpg');
  background-position: center top;
  height: 90vh;
  color: white;
}
.box{
    width: 100%;
    margin-top: 100px;
    text-align:center;
}
.branches{
	width: 90%;
	margin-left: 5%;
	margin-right: 5%;
	box-shadow: 2px 2px 3px 3px;
	max-height:200px;
	min-height: 80px;
	padding: 20px;
	margin-top: 10px;
	background-color: whitesmoke;
	transition: all 0.4s;
}
.branches:hover
{
	box-shadow: inset 0 0 0 7px brown;
	-webkit-transform: scale(1.04);
	-ms-transform: scale(1.04);
	transform: scale(1.04);
	transition: all 0.4s;
}
.button {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 80%;
  margin: 10%;
  transition: all 0.5s;
  cursor: pointer;
}
.button:hover{
	background-color: #ff8630;
}
.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}

</style>
</head>
<body>
<div id="navbar">
    <div id="d" href="">Get started</div>
    <div id="d"><a style="text-decoration:none;color: black" href="bestdeals/bestdeals.html">Best Deals</a></div>
    <div id="d" href="#contact">Contact us</div>
    <div id="name">Pizzamania</div>
    <div id="d"><a style="text-decoration:none;color: black" href="store.php">Store Locator</a></div>
    <?php
      if(isset($username)){
      echo "
        <img src=\"acc1.png\" style=\"width:50px;height:50px;display:inline;position:fixed;right:180px;top:20px;\"/><div style='display:inline-block;position:fixed;right:40px;top:20px;padding:0;font-size:22px;'>".$_SESSION['username']."</div>
	    <a style=\"font-size: 150%;font-style: oblique;font-family: monospace;position:absolute;right:50px;text-decoration:none;top:44px;cursor:pointer;\" href=\"index.php?logout='1'\">Logout</a> 
	        ";
      }
	      else{
	        echo "<a href=\"login.html\"><div id=\"d\">Login/Signup</div></a>";
	      }
	    ?>
</div>
<div id="landing-wrapper">	
	<div class="box">
		<h1 style="font-family: Bookman;
		font-size: 280%;
		margin:40px;
		color: darkred;
		color: black;
		-webkit-text-fill-color: darkred;
		-webkit-text-stroke-width: 0.4px;
		-webkit-text-stroke-color: white;">Find your nearest Pizzeria -- Using Our Pizzeria Locator</h1>
	</div>
	<?php
		$i=1;
		$database="pizzamania";
		$my=mysqli_connect("localhost","root","",$database);
		$query1 = "select DISTINCT City from pizzeria";
		$result1=$my->query($query1);
		// $query2="select city from customer where cust_id=\"".$username."\"";
		echo "<form id=\"form1\" action=\"displayitems.php\" method=\"POST\">";
		while($product=mysqli_fetch_assoc($result1)):
			// print_r($product['City']);
			$query="select * from pizzeria where City=\"".$product['City']."\"";
			$result=$my->query($query);
			if($result):
				echo "<h1 style=\"text-align:center\">".$product['City']."</h1>";
				// print_r($result);
				if(mysqli_num_rows($result)>0):?>
					<div style="clear:both"></div> 
					<?php
					while($product=mysqli_fetch_assoc($result)):
					?>
						<p class="branches">
						<input type="radio" id="test<?php echo $i;?>" name="radio-group" value="<?php echo $product['Pizzeria_id'];?>">
						<label for="test<?php echo $i;?>">Branch: <?php echo $product['Branch_Name'];?><br>Location : <?php echo $product['Address'];?></label>
						</p>
						<?php
						$i=$i+1;?>
						<?php
					endwhile;
				endif;
			endif;
		endwhile;
		echo "</form>";
		echo "<button type=\"submit\" class=\"button\" form=\"form1\"><span>Let's Go </span></button>";
		$_SESSION['username']=$username;
	?>
</div>

<div class="footer">
    <div id="name">Pizzamania</div><div class="addr"><i><span>Pizzamania Restaurant     |     901-947 South Drive, Houston, TX 77057, USA    |    Telephone: +1 555 1234</span></i></div>
</div>
<script type="text/javascript" src="index.js"></script>
</body>
</html>