<?php
session_start();
$link = mysqli_connect("localhost", "root", "","pizzamania");
if (isset($_GET['logout'])) {
      session_destroy();
      unset($_SESSION['username']);
      unset($_SESSION['shopping_cart']);
      header("location: login.html");
}
if (isset($_POST['uname']) and isset($_POST['psw'])){
//3.1.1 Assigning posted values to variables.
$username = $_POST['uname'];
$password = $_POST['psw'];
// print_r($username);
// print_r($password);
//3.1.2 Checking the values are existing in the database or not
$query = "SELECT * FROM employee WHERE username='$username' and PASSWORD='$password'";
 
$result = mysqli_query($link, $query) or die(mysqli_error($link));
$count = mysqli_num_rows($result);
//3.1.2 If the posted values are equal to the database values, then session will be created for the user.
if ($count == 1){
$_SESSION['username'] = $username;
}
else{
//3.1.3 If the login credentials doesn't match, he will be shown with an error message.
$fmsg = "Invalid Login Credentials.";
echo "<body style='margin:0;background:radial-gradient(rgba(0,0,0,0.1),rgba(0,0,0,0.3),rgba(0,0,0,0.7)),url(e1.jpg);width:100%;height:60%;'><div style='width:30%;background-color:rgba(255,255,255,0.7);border:0.3px solid grey;box-shadow:0 10px 12px rgba(178,223,219,1);color:black;text-shadow:0 3px 3px rgba(150,150,255,0.6);margin-top:16%;margin-left:30%;height:30%;padding:4%;text-align:center;font-size:150%;'>Employee Credentials Not Found!!!<br>Please retry logging in...<br><a href='login.html'><button style='background-color:darkred;border:none;color:white;width:99%;padding:3%;font-size:120%;margin-top:8%;cursor:pointer;text-shadow:0 4px 4px rgba(0,0,0,0.6);' >Login/Register</button></a></div></body>";
}    
}
//3.1.4 if the user is logged in Greets the user with message
if (isset($_SESSION['username'])){
$username = $_SESSION['username'];
echo "<!DOCTYPE html>
<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<style>
#snackbar {
    visibility: hidden;
    min-width: 250px;
    margin-left: -125px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left: 50%;
    bottom: 10%;
    font-size: 28px;
}

#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
    from {bottom: 30px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
    from {bottom: 30px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}

.loader {
  border: 16px solid whitesmoke;
  border-radius: 50%;
  border-top: 16px solid darkred;
  width: 120px;
  height: 120px;
  margin-left:48%;
  margin-top:15%;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

</style>
</head>
<body onload='myFunction()'>
<div class='loader' style='z-index:3;position:absolute;'></div>
<img src='logi.jpg'  width='100%' style='z-index: 0;position:relative;margin:0;opacity:0.5'>

<div id='snackbar'><i>Logging in as ".$username."...</i></div>
<script>
function myFunction() {
    var x = document.getElementById('snackbar');
    x.className = 'show';
    setTimeout(function(){ x.className = x.className.replace('show', ''); 
    window.location.assign(\"empcart.php\");
    }, 3000);
}
</script>
</body>
</html>
";
}
else{
    echo "Hello";
}
mysqli_close($link);
?>