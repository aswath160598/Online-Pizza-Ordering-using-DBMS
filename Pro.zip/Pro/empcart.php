
<?php
      session_start();
      extract($_SESSION);
      $link = mysqli_connect("localhost", "root", "","pizzamania");
      if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['username']);
        //unset($_SESSION['shopping_cart']);
        header("location: login.html");
      }
      // print_r($_POST);
      if(isset($_POST['acc'])){
        $x = $_POST['acc'];
        $q = "delete from order_details where order_id='$x'";
        $link->query($q);
        ?>
        <script type="text/javascript">
          window.location = "empcart.php";
        </script>
        <?php
      }
      ?>
<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="index.css">
    <style>
        table {
font-family: "Lato","sans-serif";   }       
table.one {                                 
margin-bottom: 3em;
border-collapse:collapse;   }  
td {                           
text-align: center;    
width: 10em;                   
padding: 1em;       }      
th {                             
text-align: center;                
padding: 1em;
background-color: #e8503a;      
color: white;       }                
tr {   
height: 1em;    }
table tr:nth-child(even) {            
    background-color: #eee;     }
table tr:nth-child(odd) {           
background-color:#fff;      }
    </style>
</head>
<body background="im3.jpg">

<div id="navbar">
    <div id="d" href="">Get started</div>
    <div id="d" href="#news">Best Deals</div>
    <div id="d" href="#contact">Contact us</div>
    <div id="name">Pizzamania</div>
    <div id="d" href="#store">Store Locator</div>
    <?php
      if(isset($username)){
      echo "
        <img src=\"acc1.png\" style=\"width:50px;height:50px;display:inline;position:fixed;right:180px;top:20px;\"/><div style='display:inline-block;position:fixed;right:40px;top:20px;padding:0;font-size:22px;'>".$_SESSION['username']."</div>
        <a style=\"font-size: 150%;font-style: oblique;font-family: monospace;position:absolute;right:50px;text-decoration:none;top:44px;cursor:pointer;\" href=\"index.php?logout='1'\">Logout</a> 
            ";
      }
          else{
            echo "<a href=\"login.html\"><div id=\"d\">Login/Signup</div></a>";
          }
      ?>
</div>

<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
</style>
</head>
<body>


<table style="width: 100%">
<?php
$link = mysqli_connect("localhost", "root", "","pizzamania");

$sql = "SELECT order_id,orderstatus FROM order_details";
$result = mysqli_query($link, $sql);


if (mysqli_num_rows($result) > 0) {
        echo "<tr><th>Order-ID</th><th>Cust_ID</th><th>Pizza Items</th><th>Non-Pizza Items</th><th>Total Price</th><th>Order Status</th></tr>";

    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $id=$row['order_id'];?>
        <form method='post' action='empcart.php?order_id=$id'>
        <tr>
        <td><?php echo $row["order_id"];?></td>
        <td>
          <?php
           $q = "select cust_id from order_details where order_id='$id'";
          $res = $link->query($q);
          $a = mysqli_fetch_assoc($res);
            echo $a['cust_id'];
          ?>
        </td>
        <td>
          <?php
           $q = "select * from pizza NATURAL JOIN p_order where orderid='$id'";
          $res = $link->query($q);
          if(mysqli_num_rows($res)>0){
            while($a = mysqli_fetch_assoc($res)){
              echo "<div style='padding:20px;'><img src=".$a['imageurl']." style='float:left;width:70px;height:70px'/>".$a['NAME']."<br>"."Quantity:".$a['quantity']."<br>Price: ₹ ".$a['price']*$a['quantity'].".00</div>";
          }
        }
          ?>
        </td>

        <td>
          <?php
           $q = "select * from nonpizza NATURAL JOIN np_order where orderid='$id'";
          $res = $link->query($q);
          if(mysqli_num_rows($res)>0){
            while($a = mysqli_fetch_assoc($res)){
              echo "<div style='padding:20px;'><img src=".$a['imageurl']." style='float:left;width:70px;height:70px'/>".$a['NAME']."<br>"."Quantity:".$a['quantity']."<br>Price: ₹ ".$a['price']*$a['quantity'].".00</div>";
          }
        }
          ?>
        </td>
        <td>
          <?php
           $q = "select totalprice from order_details where order_id='$id'";
          $res = $link->query($q);
          $a = mysqli_fetch_assoc($res);
            echo "₹ ".$a['totalprice'].".00";
          ?>
        </td>
        <td><button type='submit' name='acc' value='<?php echo $id;?>'>Delivered</button></td>
        </tr></form>
          <?php
      }
    }
  mysqli_close($link); 
echo "</table>";
?> 
   <div class="footer">
    <div id="name">Pizzamania</div><div class="addr"><i><span>Pizzamania Restaurant     |     901-947 South Drive, Houston, TX 77057, USA    |    Telephone: +1 555 1234</span></i></div>
</div>
</body>
</html>