<?php
session_start();
$link = mysqli_connect("localhost", "root", "","pizzamania");
if (isset($_GET['logout'])) {
session_destroy();
unset($_SESSION['username']);
unset($_SESSION['shopping_cart']);
header("location: login.html");
}
// print_r($_SESSION);
$uname=$_SESSION['username'];
if(isset($_POST)){
	$k=array_keys($_POST);
	$v=array_values($_POST);
	// print_r($v);
	if(isset($k[0])):
		$que="update customer set ".$k[0]."='".$v[0]."' where cust_id='".$uname."'";
		// echo $que;
		$resq=$link->query($que);
	endif;
}
$pizzloc=$_SESSION['location'];
$q="select * from customer where cust_id='".$uname."'";
$q4="select * from pizzeria where Pizzeria_id='".$pizzloc."'";

$res=$link->query($q);
$res4=$link->query($q4);
$r4=mysqli_fetch_assoc($res4);
$r=mysqli_fetch_assoc($res);

$order="353535";
$q1="select order_id from order_details where order_id='$order'";
$res1=$link->query($q1);
while(mysqli_num_rows($res1)>0){
		$order=$order+1;
		$q1="select order_id from order_details where order_id='$order'";
		$res1=$link->query($q1);
}

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="index.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <style type="text/css">
            label {
                margin-right: 50px;
                width: 300px;
            }
            
            input[type='text'],
            input[type='number'],
            input[type='email'],
            textarea {
                width: 60%;
            }
            
            .row {
                margin: 0 auto;
            }
        </style>
    </head>

    <body>
        <div id="landing-wrapper" style="width: 100%;height: 100vh;background:url(im2.jpg);position: absolute;background-attachment: fixed;z-index: -1;"></div>
        <nav id="navbar" class="navbar" style="padding: 20px;z-index: 5">
            <div id="d" href="">Get started</div>
            <div id="d"><a style="text-decoration:none;color: black" href="bestdealspage/best_deals.html">Best Deals</a></div>
            <div id="d" href="#contact">Contact us</div>
            <div id="name">Pizzamania</div>
            <div id="d"><a style="text-decoration:none;color: black" href="store.php">Store Locator</a></div>
            <?php
      if(isset($uname)){
      echo "
        <img src=\"acc1.png\" style=\"width:50px;height:50px;display:inline;position:fixed;right:180px;top:20px;\"/><div style='display:inline-block;position:fixed;right:40px;top:20px;padding:0;font-size:22px;'>".$_SESSION['username']."</div>
	    <a style=\"font-size: 150%;font-style: oblique;font-family: monospace;position:absolute;right:50px;text-decoration:none;top:44px;cursor:pointer;\" href=\"index.php?logout='1'\">Logout</a> 
	        ";
      }
	      else{
	        echo "<a href=\"login.html\"><div id=\"d\">Login/Signup</div></a>";
	      }
	    ?>
        </nav>
        <div class="table-responsive" style="background-color: white;margin-left:10%;margin-top:100px;margin-right: 10%;padding: 50px;border:solid brown 3px;">
            <center>
                <h1>Your order has been placed!!! Edit any of the details if necessary</h1>
            </center>
            <div class="col-sm-8" style="background-color:lavender;padding:10px">
                <form action="order.php" method="post">
                    <label for="name1">First Name</label>
                    <input id="name1" type="text" name="firstname" value=<?php echo $r[ 'firstname'];?> required>
                    <input type="submit" name="update" value="Update">
                </form>
            </div>
            <div class="col-sm-8" style="background-color:lavender;padding:10px">
                <form action="order.php" method="post">
                    <label for="name2">Last Name</label>
                    <input id="name2" type="text" name="lastname" value=<?php echo $r[ 'lastname'];?> required>
                    <input type="submit" name="update" value="Update">
                </form>
            </div>
            <div class="col-sm-8" style="background-color:lavender;padding:10px">
                <form action="order.php" method="post">
                    <label for="num">Phone Number</label>
                    <input id="num" type="number" name="phone_no" value=<?php echo $r[ 'phone_no'];?> required>
                    <input type="submit" name="update" value="Update">
                </form>
            </div>
            <div class="col-sm-8" style="background-color:lavender;padding:10px">
                <form action="order.php" method="post">
                    <label for="mail">Email ID</label>
                    <input id="mail" type="Email" name="email" value=<?php echo $r[ 'email'];?> required>
                    <input type="submit" name="update" value="Update">
                </form>
            </div>
            <div class="col-sm-8" style="background-color:lavender;padding:10px">
                <form action="order.php" method="post">
                    <label for="address">Delivery Address</label>
                    <textarea name="address" cols="40" required><?php echo htmlspecialchars($r['address']);?></textarea>
                    <input type="submit" name="update" value="Update">
                </form>
            </div>
            <div class="col-sm-8" style="background-color:lavender;padding:10px">
                <h3>Pizzeria Branch:<br></h3>
                <h4>
                    <?php echo $r4['Branch_Name'];?>
                </h4>
                <h3>Address</h3>
                <h4>
                    <?php echo $r4['Address'];?>
                </h4>
                <h3>Order No:
                    <?php echo $order;?>
                </h3>
            </div>
        </div>
        <div class="table-responsive" style="background-color: white;margin-left:50px;margin-right: 50px;padding: 20px;">
            <table class="table table-bordered">
                <tr>
                    <th width="40%">Item Name</th>
                    <th width="10%">Quantity</th>
                    <th width="20%">Price</th>
                    <th width="15%">Total</th>
                    <!-- <th width="5%">Action</th> -->
                </tr>
                <?php
			// print_r($_SESSION['shopping_cart']);
			if(!empty($_SESSION["shopping_cart"]))
			{
				$total = 0;
				foreach($_SESSION["shopping_cart"] as $keys => $values)
				{
			?>
                    <tr>
                        <td>
                            <?php echo $values["item_name"]; ?>
                        </td>
                        <td>
                            <?php echo $values["item_quantity"]; ?>
                        </td>
                        <td>₹
                            <?php echo number_format($values["item_price"], 2); ?>
                        </td>
                        <td>₹
                            <?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?>
                        </td>
                    </tr>
                    <?php
					$total = $total + ($values["item_quantity"] * $values["item_price"]);
				}
			?>
                        <tr>
                            <td colspan="3" align="right">Total</td>
                            <td align="left">₹
                                <?php echo number_format($total, 2); ?>
                            </td>
                        </tr>
                        <?php
			}
			?>
            </table>
        </div>
<!--        <button id="btn1" class="button1" style="width: 100%;margin-bottom: 50px;"><a>Place Your Order</a></button>-->
                <?php
                $q = "insert into order_details values('$order','$uname','2018-04-18','2018-04-18','YTA','$total',NULL)";
			    mysqli_query($link,$q);
			    foreach($_SESSION["shopping_cart"] as $orders){
				    extract($orders);
                    if($dessert=='N' and $drinks=='N'){
                        $query = "insert into p_order values('$item_id','$order','$item_quantity','$veg','$item_price')";
                    }
                    else{
                        $query = "insert into np_order values('$item_id','$order','$item_quantity','$item_price')";
                    }
                    $link->query($query);
                }
				?>
    </body>

    </html>