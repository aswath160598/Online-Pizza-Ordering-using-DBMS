 <?php
session_start();
extract($_SESSION);
 $link = mysqli_connect("localhost", "root", "","pizzamania");
  $q = "select * from order_details where cust_id = '$username'";
  $res = $link->query($q);
    if(mysqli_num_rows($res)>0){
      $a = mysqli_fetch_assoc($res);?>
      <script type="text/javascript">
      	alert("You have an order in progress. Please return when your order is delivered");
      	window.location = "index.php";
      </script>
      <?php
      }
  ?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="index.css">
<style type="text/css">
#search{
  text-align: center;
  font-size: 200%;
  margin-top: 1%;
  font-family: Bookman;

  -webkit-text-fill-color: darkred;
}

[type="text"]:focus{
	background-color: rgba(0,0,0,0.5);
}
#results{
  text-align: center;
  margin-top: 15%;
  font-size: 250%;
  font-family:Bookman;

}

.footer {
    margin-top: 50%; 
    width: 100%;
    background-color: whitesmoke;
}
  #landing-wrapper {
  display: table;
  width: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('im2.jpg');
  background-position: center top;
  height: 90vh;
  color: white;
}
.box{
    width: 100%;
    margin-top: 100px;
    text-align:center;
}
.branches{
	width: 90%;
	margin-left: 5%;
	margin-right: 5%;
	box-shadow: 2px 2px 3px 3px;
	max-height:200px;
	min-height: 80px;
	padding: 20px;
	margin-top: 10px;
	background-color: whitesmoke;
	transition: all 0.4s;
}
.branches:hover
{
	box-shadow: inset 0 0 0 7px brown;
	-webkit-transform: scale(1.04);
	-ms-transform: scale(1.04);
	transform: scale(1.04);
	transition: all 0.4s;
}
.button {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 80%;
  margin: 10%;
  transition: all 0.5s;
  cursor: pointer;
}
.button:hover{
	background-color: #ff8630;
}
.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>


<body>
<div id="navbar">
    <div id="d" href="">Get started</div>
     <div id="d"><a style="text-decoration:none;color: black" href="bestdeals/bestdeals.html">Best Deals</a></div>
    <div id="d" href="#contact">Contact us</div>
    <div id="name">Pizzamania</div>
    <div id="d"><a style="text-decoration:none;color: black" href="store.php">Store Locator</a></div>
  </div>


<div id="landing-wrapper">  
  <div class="box">
    <h1 style="font-family: Bookman;
    font-size: 280%;
    margin:40px;
    color: darkred;
    color: black;
    -webkit-text-fill-color: darkred;
    -webkit-text-stroke-width: 0.4px;
    -webkit-text-stroke-color: white;">Find your nearest Pizzeria -- Using Our Pizzeria Locator</h1>
  </div>


    <form action="store.php" method="POST">
    	<center><h1>Enter City</h1></center>
    <div style="font-family: Bookman;
    font-size: 280%;
    margin-left:20%;
    margin-right: 10%;
    color: darkred;
    color: black;
    -webkit-text-fill-color: white;
    -webkit-text-stroke-width: 0.4px;
    -webkit-text-stroke-color: white;"><br>
    <input type="text" autocomplete="off" placeholder="Enter City Name" style="width: 80%;border-radius: 10px;background-color: rgba(0,0,0,0.6);font-weight: 200;font-size: 30px; border-color: white;padding: 20px;" name="city">
    </div>
    <button class="button">GO</button>
    </form>
<script type="text/javascript" src="index.js"></script>


<?php 
if(isset($_POST["city"])):
  ?>
<div id="results">Search Results:-</div>
<div>
<?php
  $i=1;
  $database="pizzamania";
  $my=mysqli_connect("localhost","root","",$database);
  $var=$_POST["city"];
  $query1="select * from pizzeria where City='$var'";
  $query=$my->query($query1);
  echo "<form id=\"form1\" action=\"displayitems.php\" method=\"POST\">";
  echo "<h1 style=\"text-align:center\">".$_POST['city']."</h1>";
  while($product=mysqli_fetch_assoc($query)):
    ?>
    <p class="branches">
    <input type="radio" id="test<?php echo $i;?>" name="radio-group" value="<?php echo $product['Pizzeria_id'];?>">
    <label for="test<?php echo $i;?>">Branch: <?php echo $product['Branch_Name'];?><br>Location : <?php echo $product['Address'];?></label>
    </p>
    <?php
      $i=$i+1;?>
    <?php
    endwhile;
    echo "</form>";
    echo "<button type=\"submit\" class=\"button\" form=\"form1\"><span>Let's Go </span></button>";
    //$_SESSION['username']=$username;
    ?>
    </div>
    <?php
    endif;
    ?>

    <div class="footer">
    <div id="name">Pizzamania</div><div class="addr"><i><span>Pizzamania Restaurant     |     901-947 South Drive, Houston, TX 77057, USA    |    Telephone: +1 555 1234</span></i></div>
</div>
<script type="text/javascript" src="index.js"></script>
</body>
</html>

