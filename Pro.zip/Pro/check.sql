DROP DATABASE pizzamania;
CREATE DATABASE pizzamania;
CREATE TABLE customer(
    cust_id VARCHAR(10) PRIMARY KEY,
    address VARCHAR(100) NOT NULL,
    firstname VARCHAR(20) NOT NULL,
    lastname VARCHAR(20) NOT NULL,
    email VARCHAR(30) NOT NULL UNIQUE,
    phone_no CHAR(10) NOT NULL UNIQUE,
    city VARCHAR(30) NOT NULL,
    createdt DATETIME NOT NULL,
    passmoddt DATETIME,
    sessionid VARCHAR(10) NOT NULL UNIQUE,
    PASSWORD CHAR(10) NOT NULL
);
/*Employee finalizes the orders*/
CREATE TABLE employee(
    eid VARCHAR(5) PRIMARY KEY,
    username CHAR(10) NOT NULL,
    PASSWORD CHAR(8) NOT NULL
);
/* We will spilt the order details into pizza and non pizza items*/
CREATE TABLE order_details(
    order_id VARCHAR(10) PRIMARY KEY,
    cust_id VARCHAR(10) NOT NULL, FOREIGN KEY (cust_id) REFERENCES customer(cust_id),
    placedt DATETIME NOT NULL,
    deliverydt DATETIME NOT NULL,
    orderstatus VARCHAR(10) NOT NULL,
    totalprice FLOAT NOT NULL,
    final_eid VARCHAR(5), FOREIGN KEY (final_eid) REFERENCES employee(eid)
);
/*---------------------------------------TODO-------------------------------------*/
/* Fill in values in these tables*/
/* Contains all the pizzas in the database. Assumption is that the pizza menu displayed*/
/* on the website will always be in stock. Customer actions will not change this table.*/
CREATE TABLE pizza(
    pid VARCHAR(10) PRIMARY KEY,
    imageurl VARCHAR(200) NOT NULL,
    veg CHAR(1) NOT NULL,
    regppp FLOAT NOT NULL,
    medppp FLOAT NOT NULL,
    larppp FLOAT NOT NULL,
    NAME VARCHAR(20) NOT NULL,
    description VARCHAR(200) NOT NULL
);
/*Ingredients already added to the pizza - M*N relationship*/
CREATE TABLE pizza_ing(
    NAME VARCHAR(20) NOT NULL,
    ing_id VARCHAR(10),
    pid VARCHAR(10), FOREIGN KEY(pid) REFERENCES pizza(pid),
    price FLOAT NOT NULL
);
/*Non pizza items*/
CREATE TABLE nonpizza(
    npid VARCHAR(10) PRIMARY KEY,
    dessert CHAR(1) NOT NULL,
    drinks CHAR(1) NOT NULL,
    imageurl VARCHAR(200) NOT NULL,
    price FLOAT NOT NULL,
    NAME VARCHAR(20) NOT NULL,
    description VARCHAR(200) NOT NULL
);
/*----------------------------------TODO----------------------------------*/
/*Will include the extra ingredients chosen by the customer*/
/*M*N relationship shows quantity of each pizza ordered*/
/*Pizza type is R/M/L. While querying give separate conditions to take prices*/
/*If pizza_type is R, fetch regppp for that pid*/
CREATE TABLE p_order(
    ing_id VARCHAR(10),
    NAME VARCHAR(20) NOT NULL,
    pid VARCHAR(10) ,FOREIGN KEY(pid) REFERENCES pizza(pid),
    orderid VARCHAR(10), FOREIGN KEY(orderid) REFERENCES order_details(order_id),
    quantity INT NOT NULL,
    pizza_type CHAR(1),
    price FLOAT NOT NULL
);
/*M*N relationship to display the quantity of each non pizza item ordered*/
CREATE TABLE np_order(
    npid VARCHAR(10), FOREIGN KEY(npid) REFERENCES nonpizza(npid),
    quantity INT NOT NULL
);
/*Insert employee details*/
INSERT INTO employee VALUES('E0001', 'dinesh1011', '#beast99');
INSERT INTO employee VALUES('E0004', 'Debanik', '987654');
INSERT INTO employee VALUES('E0003', 'Aswath', 'abijna');
INSERT INTO employee VALUES('E0002', 'Deekshith', 'qwerty');

/*Insert customer details*/
INSERT INTO customer VALUES('C01','Bangalore','Aswa','Smith','abc@gmail.com','9003653456','Bangalore','2018-11-12','2018-11-12','102','abc');

INSERT INTO customer VALUES('C02','Coimnbatore','Deek','Smith','dec@gmail.com','9034653456','Coimbatore','2018-11-23','2018-11-24','103','def');

INSERT INTO customer VALUES('C03','Bangalore','Din','Brown','xyz@gmail.com','8003322456','Mangalore','2018-01-12','2018-01-12','104','123');

INSERT INTO customer VALUES('C04','Mumbai','Prem','Smith','mAb@gmail.com','9034658416','Mumbai','2018-03-21','2018-03-21','105','qwerty');

INSERT INTO customer VALUES('C05','Bangalore','Sara','Smith','123@gmail.com','5003653456','Bangalore','2018-11-12','2018-11-12','106','abc');

INSERT INTO customer VALUES('C06','Coimnbatore','Deek','Smith','212@gmail.com','9334653456','Coimbatore','2018-11-23','2018-11-24','107','def');

INSERT INTO customer VALUES('C07','Bangalore','Linda','Brown','122@gmail.com','8203322756','Mangalore','2018-01-12','2018-01-12','112','123');

INSERT INTO customer VALUES('C08','Mumbai','Watson','Smith','987@gmail.com','9034622356','Mumbai','2018-03-21','2018-03-21','108','qwerty');

INSERT INTO customer VALUES('C09','Bangalore','Deb','Brown','100@gmail.com','8883322456','Mangalore','2018-01-12','2018-01-12','109','123');

INSERT INTO customer VALUES('C010','Mumbai','Sandra','Smith','2we@gmail.com','9035653498','Mumbai','2018-03-21','2018-03-21','110','qwerty');


/*Insert all order_details */
INSERT INTO order_details VALUES('10002','C01','2018-11-12','2018-11-13','Acc',300,'E0001');

INSERT INTO order_details VALUES('10003','C02','2018-03-12','2018-03-12','No',400,'E0002');

INSERT INTO order_details VALUES('10004','C03','2018-11-12','2018-11-26','Acc',300,'E0004');

INSERT INTO order_details VALUES('10005','C04','2018-03-12','2018-03-28','No',400,'E0003');

INSERT INTO order_details VALUES('10006','C05','2018-11-12','2018-11-13','Acc',300,'E0001');

INSERT INTO order_details VALUES('10007','C06','2018-03-12','2018-03-12','No',400,'E0002');

INSERT INTO order_details VALUES('10008','C03','2018-11-12','2018-11-26','Acc',300,'E0004');

INSERT INTO order_details VALUES('10009','C04','2018-03-12','2018-03-28','No',400,'E0003');

/*Insert into all ingredients*/



/*Insert different types of pizzas */
INSERT INTO pizza VALUES('nvegpz01','C:\Users\DEEKSHITH\Desktop\DBMS_project\p1.jpg','N',89.00,128.00,178.00,'Apricot Chicken','Crispy bacon, tasty ham, pineapple, onion and stretchy mozzarella, finished with a BBQ swirl');

INSERT INTO pizza VALUES('nvegpzz02','C:\Users\DEEKSHITH\Desktop\DBMS_project\p2.jpg','N',92.00,137.00,184.00,'Chicken Hawaii','Extra-virgin olive oil, mozzarella cheese, thinly-sliced steak meat, garlic, green peppers, mushrooms and tomatoes');

INSERT INTO pizza VALUES('vegpz01','C:\Users\DEEKSHITH\Desktop\DBMS_project\p3.jpg','Y',78.00,112.00,167.00,'Grand Italiano','Quisque pretium turpis non tempus cursus. Nulla consequat, mi nec pellentesque imperdiet, mi quam congue magna, tristique commodo');


INSERT INTO pizza VALUES('vegpzz02','C:\Users\DEEKSHITH\Desktop\DBMS_project\p4.jpg','Y',81.00,128.00,181.00,'Hawaii Vegetarian','Mouth watering pepperoni, cabanossi, mushroom, capsicum, black olives and stretchy mozzarella, seasoned with garlic and oregano');

INSERT INTO pizza VALUES('vegpzz03','C:\Users\DEEKSHITH\Desktop\DBMS_project\p5.jpg','Y',76.00,118.00,176.00,'Hawaii Vegetarian','Mouth watering pepperoni, cabanossi, mushroom, capsicum, black olives and stretchy mozzarella, seasoned with garlic and oregano');

INSERT INTO pizza VALUES('vegpzz04','C:\Users\DEEKSHITH\Desktop\DBMS_project\p6.jpg','Y',81.00,132.00,178.00,'Trio Cheese','Mouth watering pepperoni, cabanossi, mushroom, capsicum, black olives and stretchy mozzarella');


INSERT INTO pizza VALUES('vegpzz05','C:\Users\DEEKSHITH\Desktop\DBMS_project\p7.jpg','Y',81.00,132.00,178.00,'Summer Pizza','Shrimp, Red Capsicum, Green Capsicum, Onion, Chilli flakes, Lemon Pepper, Mozzarella, finished with Aioli');

INSERT INTO pizza VALUES('vegpzz06','C:\Users\DEEKSHITH\Desktop\DBMS_project\p8.jpg','Y',81.00,132.00,178.00,'Pepperoni Calzone','Piled with shrimp, calamari, clams, mussels, surimi and stretchy mozzarella, seasoned with tangy lemon pepper.');

/* Insert into Non-pizza */
INSERT INTO nonpizza VALUES('dsrt01','Y','N','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr1.jpg',107.00,'Bluberry shake','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('dsrt02','Y','N','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr2.jpg',410.00,'Choclate Cake','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('dsrt03','Y','N','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr3.jpg',79.00,'Choclate Muffin','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('dsrt04','Y','N','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr5.jpg',490.00,'Red Choclate Cake','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('dsrt05','Y','N','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr6.jpg',640.00,'Red Velvet Cake','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('drnk01','N','Y','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr4.jpg',34.00,'Fresh Lime','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('drnk02','N','Y','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr7.jpg',54.00,'Cola bottle','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('drnk03','N','Y','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr8.jpg',44.00,'Ice Lime Cola','Delicious cake made of complete and pure chocolate');

INSERT INTO nonpizza VALUES('drnk04','N','Y','C:\Users\DEEKSHITH\Desktop\DBMS_project\dr9.jpg',44.00,'Iced Tea','Delicious cake made of complete and pure chocolate');

