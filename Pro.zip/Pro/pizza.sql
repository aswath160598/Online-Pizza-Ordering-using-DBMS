DROP DATABASE pizzamania;
CREATE DATABASE pizzamania; 
CREATE TABLE customer(
    cust_id VARCHAR(10) PRIMARY KEY,
    address VARCHAR(100) NOT NULL,
    firstname VARCHAR(20) NOT NULL,
    lastname VARCHAR(20) NOT NULL,
    email VARCHAR(30) NOT NULL UNIQUE,
    phone_no CHAR(10) NOT NULL UNIQUE,
    city VARCHAR(30) NOT NULL,
    createdt DATETIME NOT NULL,
    passmoddt DATETIME,
    sessionid VARCHAR(10) NOT NULL UNIQUE,
    PASSWORD CHAR(10) NOT NULL
);
/*Employee finalizes the orders*/
CREATE TABLE employee(
    eid VARCHAR(5) PRIMARY KEY,
    username CHAR(10) NOT NULL,
    PASSWORD CHAR(8) NOT NULL
);
/* We will spilt the order details into pizza and non pizza items*/
CREATE TABLE order_details(
    order_id VARCHAR(10) PRIMARY KEY,
    cust_id VARCHAR(10) NOT NULL, FOREIGN KEY (cust_id) REFERENCES customer(cust_id),
    placedt DATETIME NOT NULL,
    deliverydt DATETIME,
    orderstatus VARCHAR(10) NOT NULL,
    totalprice FLOAT NOT NULL,
    final_eid VARCHAR(5), FOREIGN KEY (final_eid) REFERENCES employee(eid)
);
/*---------------------------------------TODO-------------------------------------*/
/* Fill in values in these tables*/
/* Contains all the pizzas in the database. Assumption is that the pizza menu displayed*/
/* on the website will always be in stock. Customer actions will not change this table.*/
CREATE TABLE pizza(
    pid VARCHAR(10) PRIMARY KEY,
    imageurl VARCHAR(200) NOT NULL,
    veg CHAR(1) NOT NULL,
    regppp FLOAT NOT NULL,
    medppp FLOAT NOT NULL,
    larppp FLOAT NOT NULL,
    NAME VARCHAR(20) NOT NULL,
    description VARCHAR(200) NOT NULL
);

/*Non pizza items*/
CREATE TABLE nonpizza(
    npid VARCHAR(10) PRIMARY KEY,
    dessert CHAR(1) NOT NULL,
    drinks CHAR(1) NOT NULL,
    imageurl VARCHAR(200) NOT NULL,
    price FLOAT NOT NULL,
    NAME VARCHAR(20) NOT NULL
);

CREATE TABLE pizzeria (
  Pizzeria_id int(4) NOT NULL,
  Branch_Name varchar(20) NOT NULL,
  Address varchar(200) NOT NULL,
  City varchar(50) NOT NULL
);
/*----------------------------------TODO----------------------------------*/
/*Will include the extra ingredients chosen by the customer*/
/*M*N relationship shows quantity of each pizza ordered*/
/*Pizza type is R/M/L. While querying give separate conditions to take prices*/
/*If pizza_type is R, fetch regppp for that pid*/
CREATE TABLE p_order(
    pid VARCHAR(10) ,FOREIGN KEY(pid) REFERENCES pizza(pid),
    orderid varchar(10), FOREIGN KEY(orderid) REFERENCES order_details(order_id),
    quantity INT NOT NULL,
    pizza_type CHAR(1),
    price FLOAT NOT NULL
);
/*M*N relationship to display the quantity of each non pizza item ordered*/
CREATE TABLE np_order(
    npid VARCHAR(10), FOREIGN KEY(npid) REFERENCES nonpizza(npid),
    orderid VARCHAR(10), FOREIGN KEY(orderid) REFERENCES order_details(order_id),
    quantity INT NOT NULL,
    price FLOAT NOT NULL
);
/*Insert employee details*/
INSERT INTO employee VALUES('E0001', 'dinesh1998', '#beast99');
INSERT INTO employee VALUES('E0004', 'Debanik', '987654');
INSERT INTO employee VALUES('E0003', 'Aswath', 'abijna');
INSERT INTO employee VALUES('E0002', 'Deekshith', 'qwerty');

/*Insert different types of pizzas */
INSERT INTO pizza VALUES('nvegpzz01','display_items/ApricotChicken.jpg','N',89.00,128.00,310.00,'Apricot Chicken','Crispy bacon, tasty ham, pineapple, onion and stretchy mozzarella, finished with a BBQ swirl');
INSERT INTO pizza VALUES('nvegpzz02','display_items/ChickenHawaii.jpg','N',92.00,137.00,430.00,'Chicken Hawaii','Extra-virgin olive oil, mozzarella cheese, thinly-sliced steak meat, garlic, green peppers, mushrooms and tomatoes');
INSERT INTO pizza VALUES('vegpzz01','display_items/italiano.jpg','N',78.00,112.00,220.00,'Grand Italiano','Quisque pretium turpis non tempus cursus. Nulla consequat, mi nec pellentesque imperdiet, mi quam congue magna, tristique commodo');
INSERT INTO pizza VALUES('vegpzz02','display_items/veggie.jpg','Y',81.00,128.00,380.00,'Veggie Lover','Extra-virgin olive oil, garlic, mozzarella cheese, onions, mushrooms, green olives, black olives, fresh tomatoes');
INSERT INTO pizza VALUES('vegpzz03','display_items/HawaiiVeg.jpg','Y',76.00,118.00,300.00,'Hawaii Vegetarian','Mouth watering pepperoni, cabanossi, mushroom, capsicum, black olives and stretchy mozzarella, seasoned with garlic and oregano');
INSERT INTO pizza VALUES('vegpzz04','display_items/Trio.jpg','Y',81.00,155.00,289.00,'Trio Cheese','Mouth watering pepperoni, cabanossi, mushroom, capsicum, black olives and stretchy mozzarella');
INSERT INTO pizza VALUES('vegpzz05','display_items/summer.jpg','Y',81.00,178.00,300.00,'Summer Pizza','Shrimp, Red Capsicum, Green Capsicum, Onion, Chilli flakes, Lemon Pepper, Mozzarella, finished with Aioli');
INSERT INTO pizza VALUES('vegpzz06','display_items/pepperoni.jpg','Y',81.00,199.00,330.00,'Pepperoni Pizza','Extra-virgin olive oil, garlic, mozzarella cheese, onions, mushrooms, green olives, black olives, fresh tomatoes.');
INSERT INTO pizza VALUES('vegpzz07','display_items/pepp_calzone.jpg','Y',100.00,199.00,350.00,'Pepperoni Calzone','Extra-virgin olive oil, garlic, mozzarella cheese, onions, mushrooms, green olives, black olives, fresh tomatoes.');
INSERT INTO pizza VALUES('vegpzz08','display_items/supreme.jpg','Y',140.00,299.00,550.00,'Supreme Pizza','Ricotta, sun dried tomatoes, garlic, mozzarella cheese, topped with lightly drizzled red sauce, pesto, and fresh basil');


/* Insert into Non-pizza */
INSERT INTO nonpizza VALUES('dsrt01','Y','N','display_items/blueberry.jpg',47.00,'Bluberry shake');
INSERT INTO nonpizza VALUES('dsrt02','Y','N','display_items/choccake.jpg',110.00,'Choclate Cake');
INSERT INTO nonpizza VALUES('dsrt03','Y','N','display_items/chocmuffin.jpg',79.00,'Choclate Muffin');
INSERT INTO nonpizza VALUES('drnk01','N','Y','display_items/blackcoffee.jpg',30.00,'Black Coffee');
INSERT INTO nonpizza VALUES('drnk02','N','Y','display_items/orangejuice.jpg',80.00,'Orange Juice');
INSERT INTO nonpizza VALUES('drnk03','N','Y','display_items/lime.jpg',34.00,'Fresh Lime');
INSERT INTO nonpizza VALUES('drnk04','N','Y','display_items/cappuccino.jpg',54.00,'Hot Cappuccino');
INSERT INTO nonpizza VALUES('drnk05','N','Y','display_items/icelime.jpg',44.00,'Ice Lime Cola');
INSERT INTO nonpizza VALUES('drnk06','N','Y','display_items/icedtea.jpg',44.00,'Iced Tea');
INSERT INTO nonpizza VALUES('dsrt07','N','Y','display_items/strawberrytea.jpg',80.00,'Strawberry Tea');

/* Insert into pizzeria*/
INSERT INTO pizzeria VALUES (1000, 'Koramangala', '93/A , Apex Building, Ground Floor, A Wing ,4th B Cross, 5th Block, Koramangala, Bengaluru, Karnataka 560095', 'Bengaluru');
INSERT INTO pizzeria VALUES (1001, 'MG Road', 'No 22, Saint Marks Road, Bengaluru, Karnataka 560001', 'Bengaluru');
INSERT INTO pizzeria VALUES (1002, 'Jayanagar', '52, 1st Floor, 33rd Cross, 4th Block, Near Cafe Coffee Day, Jaya Nagar, Bengaluru, Karnataka 560011', 'Bengaluru');
INSERT INTO pizzeria VALUES (2001, 'Chemox House', 'Shop No 7, Ground Floor, Chemox House, Hospital Lane, Barrack Rd, New Marine Lines, Mumbai, Maharashtra 400020', 'Mumbai');
INSERT INTO pizzeria VALUES (2002, 'Powai', ' G-5, Ground Floor, City Park, Hiranandani Business Park, Hiranandani Gardens, Powai, Mumbai, Maharashtra 400087', 'Mumbai');
INSERT INTO pizzeria VALUES (2007, 'Santa Cruz', 'Shop No. G-102, A Wing, Orchid Pride Building, Near Vodafone Gallery, SV Road, Santacruz West, Mumbai, Maharashtra 400053', 'Mumbai');

