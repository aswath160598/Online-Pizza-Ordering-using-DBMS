	<?php
	  session_start();
	  extract($_SESSION);
	  $link = mysqli_connect("localhost", "root", "","pizzamania");
	  // if(!isset($_SESSION['cartqty'])):
	  // 	$_SESSION['cartqty']=0;
	  // endif;
	  $order="1000";
	 
	  // print_r($_POST);
	  // print_r($_SESSION);
	  if(!isset($_SESSION['location'])):
	  	$_SESSION['location']=$_POST['radio-group'];
	  endif;
	// if(empty($shopping_cart)){
	// 			echo '<script>
	// 			var a = document.querySelector(".button1");
	// 			console.log(a.target);
	// 			a.addEventListener("click",function(){
	// 				alert("You haven\'t ordered anything !!");
	// 				window.location="displayitems.php";
	// 			})
	// 			</script>';
	// }
	// else{
	// 	echo '<script>
	// 	var a = document.querySelector(".button1");
	// 	a.removeEventListener("click");
	// 	</script>';	
	// }
	  if(isset($_POST["add_to_cart"]))
	  {
		if(isset($_SESSION["shopping_cart"]))
		{
			$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
			if(!in_array($_GET["id"], $item_array_id))
			{
				$count = count($_SESSION["shopping_cart"]);
				$item_array = array(
					'veg'			    =>	$_GET["veg"],
					'dessert'			=>	$_GET["dessert"],
					'drinks'			=>	$_GET["drinks"],
					'item_id'			=>	$_GET["id"],
					'item_name'			=>	$_POST["name"],
					'item_price'		=>	$_POST["radio-group"],
					'item_quantity'		=>	$_POST["quantity"]
				);
				$_SESSION["shopping_cart"][$count] = $item_array;
			}
			else
			{
				echo '<script>alert("Item Already Added")</script>';
			}
		}
		else
		{
			$item_array = array(
				'veg'			    =>	$_GET["veg"],
				'dessert'			=>	$_GET["dessert"],
				'drinks'			=>	$_GET["drinks"],
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["name"],
				'item_price'		=>	$_POST["radio-group"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][0] = $item_array;
			
		}
		echo '<script>window.location="displayitems.php"</script>';
	}
	if(isset($_GET["action"]))
	{
		if($_GET["action"] == "delete")
		{
			foreach($_SESSION["shopping_cart"] as $keys => $values)
			{
				if($values["item_id"] == $_GET["id"])
				{
					unset($_SESSION["shopping_cart"][$keys]);
					// echo '<script>alert("Item Removed")</script>';
					echo '<script>window.location="displayitems.php"</script>';
				}
			}
		}
	}

	  // print_r($_SESSION["shopping_cart"]);
	  if (isset($_GET['logout'])) {
	    session_destroy();
	    unset($_SESSION['username']);
	    unset($_SESSION['shopping_cart']);
	    header("location: login.html");
	  }
	  ?>

	<!DOCTYPE html>
	<html>
	<head>
		<title>Pizzamania</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="index.css">
		<style type="text/css">
			#landing-wrapper{
			    display:table;
			    width:100%;
			    position: absolute;
			    background: linear-gradient( rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5) ), url('im2.jpg');
			    position: fixed;
			    background-position:center top;
			    background-attachment: fixed;
			    background-repeat: no-repeat;
	    		background-size: cover;
	    		height: 100%;
			}
			.collapsible {
			    background-color: #777;
			    color: white;
			    cursor: pointer;
			    padding: 18px;
			    width: 100%;
			    border: none;
			    text-align: left;
			    outline: none;
			    font-size: 15px;
			}

			.active, .collapsible:hover {
			    background-color: #555;
			}

			.content {
			    padding: 0 18px;
			    max-height: 0;
			    overflow: hidden;
			    transition: max-height 0.2s ease-out;
			    background-color: #f1f1f1;
			}

		</style>
	</head>

	<body>
		<div id="landing-wrapper"></div>
	<nav id="navbar" class="navbar" style="padding: 20px;z-index: 5">
	    <div id="d" href="">Get started</div>
	    <div id="d"><a style="text-decoration:none; color: black" href="bestdeals/bestdeals.html">Best Deals</a></div>
	    <div id="d" href="#contact">Contact us</div>
	    <div id="name">Pizzamania</div>
	    <div id="d"><a style="text-decoration:none;color: black"" href="store.php">Store Locator</a></div>
	    <?php
      if(isset($username)){
      echo "
        <img src=\"acc1.png\" style=\"width:50px;height:50px;display:inline;position:fixed;right:180px;top:20px;\"/><div style='display:inline-block;position:fixed;right:40px;top:20px;padding:0;font-size:22px;'>".$_SESSION['username']."</div>
	    <a style=\"font-size: 150%;font-style: oblique;font-family: monospace;position:absolute;right:50px;text-decoration:none;top:44px;cursor:pointer;\" href=\"index.php?logout='1'\">Logout</a> 
	        ";
      }
	      else{
	        echo "<a href=\"login.html\"><div id=\"d\">Login/Signup</div></a>";
	      }
	    ?>
	</nav>
	
	<h5 id="increment" style="position:fixed;right:260px;top:30px;z-index:50;cursor:pointer;"></h5>
	<div class="container" style="position: relative;">
	<?php  
		$database="pizzamania";
		$one='N';
		$two='N';
		$my=mysqli_connect("localhost","root","",$database);
		$tables=["pizza","nonpizza"];
		$headings=["Sides - Pasta,Burgers..","Dessert Delight","Enjoy Drinks"];
		$query="select * from pizza order by pid";
		$result=$my->query($query);
		$i=0;
		if($result):
			if(mysqli_num_rows($result)>0):?>
				<div style="clear:both"></div> 
				<div><h1 style="text-align: center;color: white;font-weight:600;margin-top:200px;font-family: Georgia;letter-spacing: 4px;padding: 20px;">Order Delicious Pizzas</h1></div>
				<?php
				$i=1;
				while($product=mysqli_fetch_assoc($result)):
				?>
					<div class="col-sm-4 col-md-4" style="display:block; padding:15px;background-color: white;margin-bottom: 40px">
						<form method="post" action="displayitems.php?action=add&id=<?php echo $product["pid"];?>&veg=<?php echo $product["veg"]; ?>&dessert=N&drinks=N">
							<div style="padding: 50px; border: 1px solid black;border-radius: 10px;height: 90vh;">
								<img src="<?php echo $product['imageurl'];?>"" class="img-responsive img-rounded"/>
								<h4 class="text-info" style="font-size: 150%;text-align: center"><?php echo $product["NAME"]?></h4>
								<h6 class="text-align"><?php echo $product["description"]?></h6>
								<input type="radio" id="test<?php echo $i;?>" name="radio-group" value="<?php echo $product['regppp'];?>" checked>
									<label for="test<?php echo $i;$i=$i+1;?>">Regular: ₹<?php echo $product['regppp']?>.00</label>
								<input type="radio" id="test<?php echo $i;?>" name="radio-group" value="<?php echo $product['medppp'];?>">
									<label for="test<?php echo $i;$i=$i+1;?>">Medium: ₹<?php echo $product['medppp']?>.00</label>
								<input type="radio" id="test<?php echo $i;?>" name="radio-group" value="<?php echo $product['larppp'];?>">
									<label for="test<?php echo $i;$i=$i+1;?>">Large: ₹<?php echo $product['larppp']?>.00</label>
								<br>
								<h4 style="display:block;">Quantity:</h4>
								<input type="number" name="quantity" class="form-control" value="1"/>
								<input type="hidden" name="name" value="<?php echo $product["NAME"];?>"/>
								<input type="submit" id="increment" name="add_to_cart" style="margin-top:10px" class="btn btn-info" value="Add to List"/>
							</div>
						</form>
					</div>
				<?php 
				endwhile;
			endif;
		endif;
		?>
		<?php
		$one='N';
		$two='N';
		for($i=0;$i<3;$i++):
			$query="select * from nonpizza where dessert='$one' and drinks='$two'";
			$result=$my->query($query);
			if($result):
				if(mysqli_num_rows($result)>0):?>
					<div style="clear:both"></div> 
					<div style="position:width: 100%;font-family: Georgia;margin-top: 70px; letter-spacing: 4px;"><h1 style="color: white;font-weight:600;text-align: center"><?php echo $headings[$i];?></h1></div>
					<?php
					while($product=mysqli_fetch_assoc($result)):
					?>
						<div class="col-sm-4 col-md-4" style="padding:15px;background-color: white;margin-bottom: 40px;">
							<form method="post" action="displayitems.php?action=add&id=<?php echo $product["npid"]; ?>&veg=Y&dessert=<?php echo $one;?>&drinks=<?php echo $two;?>">
								<div style="padding: 50px;border: 1px solid black;border-radius: 10px;">
									<img src="<?php echo $product['imageurl'];?>"" class="img-responsive img-rounded"/>
									<h4 class="text-info" style="font-size: 150%;text-align: center"><?php echo $product["NAME"]?></h4>
										<?php 
										if(isset($product["description"])):
											echo $product["description"];
										endif;?>
									<input type="radio" name="radio-group" value="<?php echo $product['price'];?>" checked>
										<label><h4>Cost: ₹<?php echo $product['price']?>.00</h4></label>
										<br>
									<h4 style="display: inline-block;">Quantity:</h4>
									<input type="number" name="quantity" class="form-control" value="1"/>
									<input type="hidden" name="name" value="<?php echo $product["NAME"];?>"/>
									<input type="submit" name="add_to_cart" style="margin-top:10px" class="btn btn-info" value="Add to List"/>
								</div>
							</form>
						</div>
					<?php 
					endwhile;
				endif;
		endif;
			if($one==='N'){
				$one='Y';
			}
			else if($one==='Y'){
				$one='N';
				$two='Y';
			}
		endfor;

	if(isset($_SESSION['shopping_cart'])):
		echo '<a href="#con" style="transition:1s;"><img src="cartimg.png" width="30px" height="30px" style="position:fixed;right:270px;top:30px;z-index:50;cursor:pointer;"/></a>';
		?>

	<div style="clear:both"></div>
	<br />
	<button id="orderdet" class="collapsible" style="background-color: orange;margin-bottom: 50px;margin-top: 50px;">Your Order</button>
	<div id="con" class="content" style="background-color: rgba(255,255,255,0.5);margin-bottom: 50px;transition: 1s;">
	<!-- <h3 id="ordervisit" style="color: white">Order Details</h3> -->
	<div class="table-responsive" style="background-color: white;margin: 50px;">
		<table class="table table-bordered">
			<tr>
				<th width="40%">Item Name</th>
				<th width="10%">Quantity</th>
				<th width="20%">Price</th>
				<th width="15%">Total</th>
				<th width="5%">Action</th>
			</tr>
			<?php
			if(!empty($_SESSION["shopping_cart"]))
			{
				$total = 0;
				foreach($_SESSION["shopping_cart"] as $keys => $values)
				{
			?>
			<tr>
				<td><?php echo $values["item_name"]; ?></td>
				<td><?php echo $values["item_quantity"]; ?></td>
				<td>₹ <?php echo $values["item_price"]; ?></td>
				<td>₹ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></td>
				<td><a href="displayitems.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>
			</tr>
			<?php
					$total = $total + ($values["item_quantity"] * $values["item_price"]);
				}
			?>
			<tr>
				<td colspan="3" align="right">Total</td>
				<td align="right">₹ <?php echo number_format($total, 2); ?></td>
				<td></td>
			</tr>
			<?php
			}
			?>				
		</table>
	</div>
	<button class="button1" style="width: 100%;margin-bottom: 50px;"><a href="order.php">Place Your Order</a></button>
	</div>
	<?php
		endif;
		?>
	<div style="clear:both"></div>
	<div class="footer" style="width: 100%;">
	    <div id="name">Pizzamania</div>
	    <div class="addr">
	    	<i><span>Pizzamania Restaurant     |     901-947 South Drive, Houston, TX 77057, USA    |    Telephone: +1 555 1234</span></i>
	    </div>
	    <div class="icon"><img src="facebook.png" width="100%" ></div>
	    <div class="icon"><img src="twitter.png" width="100%" ></div>
	    <div class="icon"><img src="instagram.png" width="100%" ></div>
	    <div class="icon"><img src="web.png" width="100%" ></div>
	</div>
</div>
	<script>
	var coll = document.getElementsByClassName("collapsible");
	var i;

	for (i = 0; i < 1; i++) {
	  coll[i].addEventListener("click", function() {
	    this.classList.toggle("active");
	    var content = this.nextElementSibling;
	    if (content.style.maxHeight){
	      content.style.maxHeight = null;
	    } else {
	      content.style.maxHeight = content.scrollHeight + "px";
	    } 
	  });
	}
	</script>

	<script type="text/javascript" src="index.js"></script>
	</body>
	</html>



