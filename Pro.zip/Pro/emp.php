

<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="index.css">
    <style>
        table {
font-family: "Lato","sans-serif";   }       
table.one {                                 
margin-bottom: 3em;
border-collapse:collapse;   }  
td {                           
text-align: center;    
width: 10em;                   
padding: 1em;       }      
th {                             
text-align: center;                
padding: 1em;
background-color: #e8503a;      
color: white;       }                
tr {   
height: 1em;    }
table tr:nth-child(even) {            
    background-color: #eee;     }
table tr:nth-child(odd) {           
background-color:#fff;      }
    </style>
</head>
<body background="im3.jpg">

<div id="navbar">
    <div id="d" href="">Get started</div>
    <div id="d" href="bestdealspage/best_deals.html">Best Deals</div>
    <div id="d" href="#contact">Contact us</div>
    <div id="name">Pizzamania</div>
    <div id="d" href="#store">Store Locator</div>
    <?php
      if(isset($username)){
      echo "
        <img src=\"acc1.png\" style=\"width:50px;height:50px;display:inline;position:fixed;right:120px;top:20px;\"/>
        <a style=\"font-size: 150%;font-style: oblique;font-family: monospace;position:fixed;right:30px;top:30px;cursor:pointer;\" href=\"index.php?logout='1'\">Logout</a> 
        ";
      }
      else{
        echo "<a href=\"login.html\"><div id=\"d\">Login/Signup</div></a>";
      }
    ?>
</div>
<table>
    <form method="post" action="">
<?php
function order()
{
// Create connection
$link = mysqli_connect("localhost", "root", "","pizzamania");

$sql = "SELECT order_id,orderstatus FROM order_details";
$result = mysqli_query($link, $sql);


if (mysqli_num_rows($result) > 0) {
        echo "<tr><th>Order-ID</th><th>       Order Status     </th></tr>";

    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $id=$row['order_id'];
        echo  "<tr><td>" . $row["order_id"]. "  </br>  " . "</td><td><button type='submit' name='acc' value='{$id}'>Accept</button>". "</tr>";
    }
}
     if (isset($_POST['acc']) && intval($_POST['acc'])) {
        $user_id = (int) $_POST['acc'];
     }
       
    echo "</table>";
mysqli_close($link);
} 
        order();


?> 
</form> 
</table>
    <div class="footer">
    <div id="name">Pizzamania</div><div class="addr"><i><span>Pizzamania Restaurant     |     901-947 South Drive, Houston, TX 77057, USA    |    Telephone: +1 555 1234</span></i></div>
</div>
</body>
</html>