<?php
  session_start();
  extract($_SESSION);
  $link = mysqli_connect("localhost", "root", "","pizzamania");
  $q = "select * from order_details where cust_id = '$username'";
  $res = $link->query($q);

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.html");
  }
  ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
<div id="navbar">
    <div id="d" href="">Get started</div>
    <div id="d"><a style="text-decoration:none;color: black" href="bestdealspage/best_deals.html">Best Deals</a></div>
    <div id="d" href="#contact">Contact us</div>
    <div id="name">Pizzamania</div>
    <div id="d"><a href="store.php" style="text-decoration:none">Store Locator</a></div>
    <?php 
    if(mysqli_num_rows($res)>0){
      $a = mysqli_fetch_assoc($res);
      if(isset($a['orderstatus']) && $a['orderstatus']=="YTA"){
        echo "<h5 style='position:fixed;right:280px;top:5px;'>Latest Order<br>Delivery<br>pending</h5>";
      }
    }
    else{
        echo "<h5 style='position:fixed;right:280px;top:5px;'>Latest Order<br>Delivered!</h5>";
      }
    if(isset($username)){
      echo "
        <img src=\"acc1.png\" style=\"width:50px;height:50px;display:inline;position:fixed;right:180px;top:20px;\"/><div style='display:inline-block;position:fixed;right:40px;top:20px;padding:0;font-size:22px;'>".$_SESSION['username']."</div>
        <a style=\"font-size: 150%;font-style: oblique;font-family: monospace;position:absolute;right:50px;text-decoration:none;top:44px;cursor:pointer;\" href=\"index.php?logout='1'\">Logout</a> 
          ";
      }
      else{
        echo "<a href=\"login.html\"><div id=\"d\">Login/Signup</div></a>";
      }
    ?>
</div>
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="im1.jpg" style="width:100%;height:1000px;">
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="im2.jpg" style="width:100%;height:1000px;">
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="im3.jpg" style="width:100%;height:1000px;">
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div><br>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="p1.jpg" style="width:100%">
      <div class="container">
        <p id="h2">Apricot Chicken</p>
        <p id="p"><i>Crispy bacon, tasty ham, pineapple, onion and stretchy mozzarella, finished with a BBQ swirl</i></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="p2.jpg"  style="width:100%">
      <div class="container">
        <p id="h2">Chicken Hawaii</p>
        <p id="p"><i>Extra-virgin olive oil, mozzarella cheese, thinly-sliced steak meat, garlic, green peppers, mushrooms and tomatoes</i></p>
      </div>
    </div>
  </div>
    
  <div class="column">
    <div class="card">
      <img src="p3.jpg"  style="width:100%">
      <div class="container">
        <p id="h2">Grand Italiano</p>
        <p id="p"><i>Quisque pretium turpis non tempus cursus. Nulla consequat, mi nec pellentesque imperdiet, mi quam congue magna, tristique commodo.</i></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="p4.jpg"  style="width:100%">
      <div class="container">
        <p id="h2">Hawaii Vegetarian</p>
        <p id="p"><i>Mouth watering pepperoni, cabanossi, mushroom, capsicum, black olives and stretchy mozzarella, seasoned with garlic and oregano.</i></p>
      </div>
    </div>
  </div>
</div>
<button class="button1"><span>See More </span></button><br><br><br><br><hr>
    <div class="row">
  <div class="column">
    <div class="card">
      <img src="dr1.jpg" style="width:100%">
      <div class="container1">
          <p id="h2"><i>Blueberry Shake</i></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="dr2.jpg"  style="width:100%">
      <div class="container1">
          <p id="h2"><i>Chocolate cake</i></p>
      </div>
    </div>
  </div>
    
  <div class="column">
    <div class="card">
      <img src="dr3.jpg"  style="width:100%">
      <div class="container1">
          <p id="h2"><i>Chocolate Muffin</i></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="dr4.jpg"  style="width:100%">
      <div class="container1">
          <p id="h2"><i>Fresh lime</i></p>
      </div>
    </div>
  </div>
</div>
<button class="button1"><span>See More </span></button><br><br><br><br><hr>

<div class="row">
  <div class="column">
    <div class="card">
      <img src="b1.png" style="width:100%">
      <div class="container">
        <p id="h2">Bacon Burger</p>
        <p id="p"><i>A mighty meaty double helping of all the reasons you love our burger</i></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="b2.png"  style="width:100%">
      <div class="container">
        <p id="h2">Cheese Burger</p>
        <p id="p"><i>A mighty meaty double helping of all the reasons you love our burger.</i></p>
      </div>
    </div>
  </div>
    
  <div class="column">
    <div class="card">
      <img src="b3.png"  style="width:100%">
      <div class="container">
        <p id="h2">Chicken Burger</p>
        <p id="p"><i>A mighty meaty double helping of all the reasons you love our burger.</i></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="b4.png"  style="width:100%">
      <div class="container">
        <p id="h2">Country Burger</p>
        <p id="p"><i>A mighty meaty double helping of all the reasons you love our burger.</i></p>
      </div>
    </div>
  </div>
</div>
<button class="button1"><span>See More </span></button><br><br><br><br><hr>
<div class="nws"><div id="nws">SUBSCRIBE TO OUR NEWSLETTER<br><form><input id="ip1" type="email" placeholder="Type here your email address to receive newsletter"><input type="submit" id="ip2" value="Sign Up" ></form></div></div>
<div class="footer">
    <div id="name">Pizzamania</div><div class="addr"><i><span>Pizzamania Retaurant     |     901-947 South Drive, Houston, TX 77057, USA    |    Telephone: +1 555 1234</span></i></div><div class="icon"><img src="facebook.png" width="100%" ></div><div class="icon"><img src="twitter.png" width="100%" ></div><div class="icon"><img src="instagram.png" width="100%" ></div><div class="icon"><img src="web.png" width="100%" ></div></div>
<script type="text/javascript" src="index.js"></script>
</body>
</html>