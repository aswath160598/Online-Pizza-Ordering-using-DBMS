<?php
session_start();
$link = mysqli_connect("localhost", "root", "","pizzamania");
// Check connection
extract($_POST);
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "SELECT * FROM customer WHERE cust_id='$uname'";
$result = mysqli_query($link, $sql);
if(mysqli_num_rows($result) > 0){
    echo "Account already exists,please try loggin in with your credentials";
}
else{
$sql = "INSERT INTO customer (cust_id,address,firstname,lastname,email,phone_no,city,createdt,sessionid,PASSWORD) VALUES ('$uname','$addr','$fname','$lname','$email','$phno','$city','date(\"r\")','$uname','$psw')";
mysqli_query($link, $sql);
// echo "<script>alert("Registered Successfully!!");</script>";
echo "<script>setTimeout(function(){window.location.assign(\"login.html\"); }, 1500);}</script>";
}
mysqli_close($link);
?>